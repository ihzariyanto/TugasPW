<!DOCTYPE html>
<html>
<head>
	<title>SPBU</title>
</head>
<body>
	<?php $nama = $BBM = $jumlah = ""; ?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		Name :<input type="text" name="name"><br><br>
		Bahan Bakar Minyak :<br>
		<input type="radio" name="BBM" <?php if (isset($BBM) && $BBM=="solar") echo "checked";?> value="solar">Solar
		  <input type="radio" name="BBM" <?php if (isset($BBM) && $BBM=="premium") echo "checked";?> value="premium">Premium
		  <input type="radio" name="BBM" <?php if (isset($BBM) && $BBM=="pertalite") echo "checked";?> value="pertalite">Pertalite
		  <input type="radio" name="BBM" <?php if (isset($BBM) && $BBM=="pertamax") echo "checked";?> value="pertamax">Pertamax
		  <br><br>
		  Jumlah: <input type="number" name="jumlah" value="<?php echo $jumlah;?>">
		  <span class="error">
		  <br><br>
		  <br><br>
		  <input type="submit" name="submit" value="Submit">
	</form>
	<?php 
		if ($_SERVER['REQUEST_METHOD']=="POST") {
			$nama = $_POST['name'];
			$BBM = $_POST['BBM'];
			$jumlah = $_POST['jumlah'];
			switch ($BBM) {
			    case "solar":
			        $harga=5150;
			        break;
			    case "premium":
			        $harga=6550;
			        break;
			    case "pertalite":
			        $harga=7500;
			        break;
			    default:
			        $harga=8250;
			}
		}
		echo "<h2>Your Input:</h2>";
		echo "Nama :" . $nama;
		echo "<br>";
		echo "Jenis BBM	:" . $BBM;
		echo "<br>";
		echo "Jumlah uang :" . $jumlah;
		echo "<br>";

		echo "<h2>Your Input:</h2>";
		echo "Jumlah liter:\t" . round($jumlah / $harga, 2, PHP_ROUND_HALF_EVEN);
		echo "<br>";
	 ?>
</body>
</html>
