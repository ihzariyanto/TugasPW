<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
		Name : <input type="text" name="name">
		<br>
		NPM : <input type="number" name="npm">
	<table method="post" action="index.php">
		  <tr>
		    <th>No</th>
		    <th>Sandi</th>
		    <th>MataKuliah</th>
		    <th>SKS</th>
		    <th>Nilai Huruf</th>
		  </tr>
		  <tr>
		    <td>1</td>
		    <td>D10K.0400305</td>
		    <td>Sistem Database II</td>
		    <td><input type="number" name="SKSsisdat2" id="sksSisdat2"></td>
		    <td><input type="text" name="Nilaisisdat2" id="sisdat2" ></td>
		  </tr>
		  <tr>
		    <td>2</td>
		    <td>D10K.0400503</td>
		    <td>Entreupeneur</td>
		    <td><input type="number" name="SKSentre" id="sksEntre"></td>
		    <td><input type="text" name="Nilaientre" id="entre"></td>
		  </tr>
		  <tr>
		    <td>3</td>
		    <td>D10A.3202</td>
		    <td>Pemrograman Web</td>
		    <td><input type="number" name="SKSpw" id="sksPW"></td>
		    <td><input type="text" name="Nilaipw" id="pw"></td>
		  </tr>
		  <tr>
		    <td>4</td>
		    <td>D10G.3203</td>
		    <td>Pemrograman Berbasis Objek</td>
		    <td><input type="number" name="SKSoop" id="sksOOP"></td>
		    <td><input type="text" name="Nilaioop" id="oop"></td>
		  </tr>
		  <tr>
		    <td>5</td>
		    <td>D10G.3201</td>
		    <td>Sistem Operasi</td>
		    <td><input type="number" name="SKSso" id="sksSO"></td>
		    <td><input type="text" name="Nilaiso" id="so"></td>
		  </tr>
	</table>
	<button type="submit" onclick="deklarasiSKS()">Submit</button>
	</form>
	<?php 
	
			$sksSisdat2 = $sksSO = $sksOOP = $sksPW =$sksEntre = "";
			if ($_SERVER['REQUEST_METHOD']=="POST") {
				$sksSisdat2= $_POST['SKSsisdat2'];
				$sksSO= $_POST['SKSso'];
				$sksOOP=$_POST['SKSoop'];
				$sksPW= $_POST['SKSpw'];
				$sksEntre=$_POST['SKSentre'];
			}
			echo "<h2> Your SKS Input: </h2><br>";
			echo "SKS SISDAT2 :$sksSisdat2"; 
			echo "<br>";
			echo "SKS SO :$sksSO";
			echo "<br>" ;
			echo "SKS OOP :$sksOOP";
			echo "<br>" ;
			echo "SKS Entre :$sksEntre";
			echo "<br>"; 
			echo "SKS PW :$sksPW";
		
	
			$nilaiSisdat2 = $nilaiSO = $nilaiOOP = $nilaiPW = $nilaiEntre = "";
			if ($_SERVER['REQUEST_METHOD']=="POST") {
				$nilaiSisdat2 = $_POST['Nilaisisdat2'];
				$nilaiEntre = $_POST['Nilaientre'];
				$nilaiPW = $_POST['Nilaipw'];
				$nilaiOOP = $_POST['Nilaioop'];
				$nilaiSO = $_POST['Nilaiso'];
			}
			//Konversi Huruf ke Nilai
			//Sisdat2
			if ($nilaiSisdat2 == 'A' || $nilaiSisdat2 == 'a') {
				$nilaiSisdat2 = 4;
			}else if($nilaiSisdat2 =='B' || $nilaiSisdat2 == 'b'){
				$nilaiSisdat2 = 3;
			}else if($nilaiSisdat2== 'C' || $nilaiSisdat2 == 'c'){
				$nilaiSisdat2 = 2;
			}else if ($nilaiSisdat2 == 'D' || $nilaiSisdat2 == 'd') {
				$nilaiSisdat2 = 1;
			}else if ($nilaiSisdat2 == 'E' || $nilaiSisdat2 == 'e'){
				$nilaiSisdat2 = 0;
			}
			//Entre
			if ($nilaiEntre == 'A' || $nilaiEntre == 'a') {
				$nilaiEntre = 4;
			}else if($nilaiEntre =='B' || $nilaiEntre == 'b'){
				$nilaiEntre = 3;
			}else if($nilaiEntre== 'C' || $nilaiEntre == 'c'){
				$nilaiEntre = 2;
			}else if ($nilaiEntre == 'D' || $nilaiEntre == 'd') {
				$nilaiEntre = 1;
			}else if ($nilaiEntre == 'E' || $nilaiEntre == 'e'){
				$nilaiEntre = 0;
			}
			//OOP
			if ($nilaiOOP == 'A' || $nilaiOOP == 'a') {
				$nilaiOOP = 4;
			}else if($nilaiOOP =='B' || $nilaiOOP == 'b'){
				$nilaiOOP = 3;
			}else if($nilaiOOP== 'C' || $nilaiOOP == 'c'){
				$nilaiOOP = 2;
			}else if ($nilaiOOP == 'D' || $nilaiOOP == 'd') {
				$nilaiOOP = 1;
			}else if ($nilaiOOP == 'E' || $nilaiOOP == 'e'){
				$nilaiOOP = 0;
			}
			//PW
			if ($nilaiPW == 'A' || $nilaiPW == 'a') {
				$nilaiPW = 4;
			}else if($nilaiPW =='B' || $nilaiPW == 'b'){
				$nilaiPW = 3;
			}else if($nilaiPW== 'C' || $nilaiPW == 'c'){
				$nilaiPW = 2;
			}else if ($nilaiPW == 'D' || $nilaiPW == 'd') {
				$nilaiPW = 1;
			}else if ($nilaiPW == 'E' || $nilaiPW == 'e'){
				$nilaiPW = 0;
			}
			//nilai SO
			if ($nilaiSO == 'A' || $nilaiSO == 'a') {
				$nilaiSO = 4;
			}else if($nilaiSO =='B' || $nilaiSO == 'b'){
				$nilaiSO = 3;
			}else if($nilaiSO== 'C' || $nilaiSO == 'c'){
				$nilaiSO = 2;
			}else if ($nilaiSO == 'D' || $nilaiSO == 'd') {
				$nilaiSO = 1;
			}else if ($nilaiSO == 'E' || $nilaiSO == 'e'){
				$nilaiSO = 0;
			}
			else {
				echo "<br>Anda Salah Memasukan Nilai";
			}
			echo "<h2> Your HM Input: </h2><br>";
			echo "nilai Sisdat2: $nilaiSisdat2";
			echo "<br>";
			echo "nilai SO: $nilaiSO";
			echo "<br>";
			echo "nilai OOP: $nilaiOOP";
			echo "<br>";
			echo "nilai Entre: $nilaiEntre";
			echo "<br>";
			echo "nilai PW: $nilaiPW";
			echo "<br>";

			function perhitungan(){ 
				echo "<h2>IP konversi<br></h2>";
				global $sksSisdat2 , $sksSO , $sksOOP , $sksPW ,$sksEntre, $nilaiSisdat2 , $nilaiSO , $nilaiOOP , $nilaiPW , $nilaiEntre;
				$jumlahSKS = ($sksSisdat2 + $sksSO + $sksOOP + $sksPW +$sksEntre );
				$hasil =($nilaiSisdat2*$sksSisdat2 + $nilaiSO*$sksSO + $nilaiOOP*$sksOOP + $nilaiPW*$sksPW + $nilaiEntre*$sksEntre)/$jumlahSKS;
				echo "Jumlah SKS : $jumlahSKS";
				echo "<br>";
				echo "IP : $hasil";
			}
			perhitungan();
	 ?>
</body>
</html>
