<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset ="utf-8">
        <title>Cookie View Example</title>
    </head>

    <body>
        <a href= 'Cookie_controller/display_cookie'>Click here</a> to view the box.<br>
        <a href= 'delete_cookie'>Click here</a> to delete the cookie.
    </body>
</html>