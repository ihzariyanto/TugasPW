<?php
    class Session_controller extends CI_Controller
    {
        public function index()
        {
            $this->load->library('session'); //loading session lib
            $this->session->set_userdata('name','ical'); //adding data
            $this->load->view('session_view');
        }

        public function get()
        {
            $this->load->library('session'); //loading session lib
            
        }

        public function unset_session()
        {
            $this->load->library('session');//loading session lib
            $this->session->sess_destroy('name');//removing session
            $this->load->view('session_view');
        }

    }
?>