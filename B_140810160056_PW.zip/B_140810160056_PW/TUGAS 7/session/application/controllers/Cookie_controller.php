<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Cookie_controller extends CI_Controller
    {
        function __construct()
        {
            parent::__construct();
            $this->load->helper(array('cookie','url'));
        }
        
        public function index()
        {
            set_cookie('nama','Ical Lucu','3600');
            $this->load->view('Cookie_view');
        }

        public function display_cookie()
        {
            echo get_cookie('nama');
            $this->load->view('Cookie_view');
        }

        public function delete_cookie()
        {
            delete_cookie('nama');
            redirect('Cookie_controller');
        }
    }
?>